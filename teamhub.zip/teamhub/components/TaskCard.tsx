'use client';
import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { Avatar, Badge, Button, Card, Input } from '@/components/ui/ui';
import { timeAgo, cn } from '@/lib/utils';
import type { Profile, Reply, Task, TaskStatus } from '@/lib/types';

const STATUS: { id: TaskStatus; label: string }[] = [{ id: 'open', label: 'Open' }, { id: 'in_progress', label: 'In progress' }, { id: 'done', label: 'Done' }];

export default function TaskCard({ task, replies, people, onChange }: { task: Task; replies: Reply[]; people: Map<string, Profile>; onChange: () => void }) {
  const { profile } = useAuth();
  const [text, setText] = useState('');
  const [open, setOpen] = useState(false);
  const [err, setErr] = useState('');
  const author = people.get(task.author_id);
  const owner = !!profile?.is_owner;
  const canEdit = owner || profile?.id === task.author_id;

  const run = async (p: PromiseLike<{ error: { message: string } | null }>) => { const { error } = await p; setErr(error?.message ?? ''); onChange(); };
  const reply = async (e: React.FormEvent) => {
    e.preventDefault(); if (!text.trim()) return;
    await run(supabase.from('task_replies').insert({ task_id: task.id, body: text.trim() }));
    setText('');
  };

  return (
    <Card className={cn('rise p-6', task.pinned && 'border-coral/40 coral-glow')}>
      <div className="flex flex-wrap items-center gap-2">
        {task.pinned && <Badge>📌 Pinned</Badge>}
        <Badge className={task.status === 'done' ? 'bg-emerald-400/15 text-emerald-200' : task.status === 'in_progress' ? 'bg-amberx/15 text-amber-100' : 'bg-white/10 text-slate-300'}>
          {STATUS.find((s) => s.id === task.status)?.label}
        </Badge>
        <span className="ml-auto text-xs text-slate-500">{timeAgo(task.created_at)}</span>
      </div>
      <h3 className="display mt-4 text-xl font-bold">{task.title}</h3>
      {task.body && <p dir="auto" className="mt-2 whitespace-pre-wrap text-sm leading-6 text-slate-400">{task.body}</p>}
      <div className="mt-4 flex items-center gap-2 text-xs text-slate-400"><Avatar name={author?.display_name} url={author?.avatar_url} size={22} />{author?.display_name ?? 'Member'}</div>

      <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-white/10 pt-4">
        <button onClick={() => setOpen(!open)} className="text-sm font-semibold text-coral">{replies.length} {replies.length === 1 ? 'reply' : 'replies'} {open ? '▴' : '▾'}</button>
        <div className="ml-auto flex flex-wrap gap-2 text-xs">
          {canEdit && (
            <select value={task.status} onChange={(e) => run(supabase.from('tasks').update({ status: e.target.value }).eq('id', task.id))} className="rounded-lg border border-white/10 bg-card px-2 py-1.5 text-white outline-none">
              {STATUS.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
            </select>
          )}
          {owner && <button onClick={() => run(supabase.from('tasks').update({ pinned: !task.pinned }).eq('id', task.id))} className="rounded-lg border border-white/10 px-3 py-1.5 hover:border-coral/50">{task.pinned ? 'Unpin' : 'Pin'}</button>}
          {canEdit && <button onClick={() => confirm('Delete this task?') && run(supabase.from('tasks').delete().eq('id', task.id))} className="rounded-lg border border-white/10 px-3 py-1.5 text-red-300 hover:border-red-400/50">Delete</button>}
        </div>
      </div>
      {err && <p className="mt-2 text-xs text-red-300">{err}</p>}
      {open && (
        <div className="mt-4 space-y-3">
          {replies.map((r) => {
            const a = people.get(r.author_id);
            return (
              <div key={r.id} className="flex gap-3 rounded-2xl bg-white/5 p-3">
                <Avatar name={a?.display_name} url={a?.avatar_url} size={28} />
                <div className="min-w-0"><p className="text-xs text-slate-400"><b className="text-slate-200">{a?.display_name ?? 'Member'}</b> · {timeAgo(r.created_at)}</p><p dir="auto" className="mt-1 whitespace-pre-wrap break-words text-sm">{r.body}</p></div>
              </div>
            );
          })}
          <form onSubmit={reply} className="flex gap-2"><Input dir="auto" className="mt-0" placeholder="Write a reply..." value={text} onChange={(e) => setText(e.target.value)} /><Button type="submit">Reply</Button></form>
        </div>
      )}
    </Card>
  );
}
