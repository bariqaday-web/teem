'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/lib/auth';
import { Avatar } from '@/components/ui/ui';
import { cn } from '@/lib/utils';

const LINKS = [
  { href: '/workspace', label: 'Workspace', icon: '◈' },
  { href: '/chat', label: 'Chat', icon: '✉' },
  { href: '/tasks', label: 'Tasks', icon: '✦' },
  { href: '/people', label: 'People', icon: '◉' }
];

export default function Sidebar() {
  const path = usePathname();
  const { profile, signOut } = useAuth();
  return (
    <>
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-white/10 bg-[#0A0A0C]/80 p-5 backdrop-blur-xl md:flex">
        <p className="display text-lg font-bold">Team<span className="text-coral">Hub</span> <i className="ml-1 inline-block h-2 w-2 rounded-full bg-coral shadow-[0_0_12px_#FF5E36]" /></p>
        <nav className="mt-10 flex flex-1 flex-col gap-1">
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} className={cn('flex items-center gap-3 rounded-xl px-4 py-3 text-sm transition', path.startsWith(l.href) ? 'bg-coral/15 font-semibold text-orange-100 ring-1 ring-coral/30' : 'text-slate-400 hover:bg-white/5 hover:text-white')}>
              <span className="text-coral">{l.icon}</span>{l.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-3">
          <Avatar name={profile?.display_name} url={profile?.avatar_url} />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold">{profile?.display_name}</p>
            <button onClick={signOut} className="text-xs text-slate-500 hover:text-coral">Sign out</button>
          </div>
        </div>
      </aside>
      <nav className="fixed inset-x-0 bottom-0 z-40 flex border-t border-white/10 bg-[#0A0A0C]/90 backdrop-blur-xl md:hidden">
        {LINKS.map((l) => (
          <Link key={l.href} href={l.href} className={cn('flex flex-1 flex-col items-center gap-1 py-3 text-[11px]', path.startsWith(l.href) ? 'text-coral' : 'text-slate-500')}>
            <span className="text-base">{l.icon}</span>{l.label}
          </Link>
        ))}
      </nav>
    </>
  );
}
