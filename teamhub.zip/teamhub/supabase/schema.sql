-- ============================================================
-- TeamHub — مخطط قاعدة البيانات (شغّله كاملاً في Supabase > SQL Editor)
-- آمن لإعادة التشغيل. أول حساب يسجّل يصبح "المالك" (Owner) تلقائياً.
-- ============================================================

-- 1) الملفات الشخصية
create table if not exists public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  specialty    text check (specialty in ('frontend','backend','fullstack','mobile','ui_ux','devops','ai','qa')),
  bio          text check (bio is null or char_length(bio) <= 500),
  avatar_url   text,
  is_owner     boolean not null default false,
  onboarded    boolean not null default false,
  created_at   timestamptz not null default now()
);
alter table public.profiles enable row level security;

-- دالة تتحقق هل المستخدم الحالي مالك (security definer لتجنب تكرار RLS)
create or replace function public.is_owner()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select is_owner from public.profiles where id = auth.uid()), false)
$$;

drop policy if exists "profiles_select_auth" on public.profiles;
create policy "profiles_select_auth" on public.profiles for select to authenticated using (true);
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- المستخدم لا يستطيع تعديل is_owner أبداً (الأعمدة المسموحة فقط)
revoke insert, update on public.profiles from authenticated, anon;
grant update (display_name, specialty, bio, avatar_url, onboarded) on public.profiles to authenticated;

-- إنشاء الملف الشخصي عند التسجيل؛ أول حساب = مالك
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name, is_owner)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'), ''), split_part(new.email, '@', 1)),
    not exists (select 1 from public.profiles)
  ) on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- 2) المحادثة
create table if not exists public.messages (
  id         bigint generated always as identity primary key,
  user_id    uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  content    text check (content is null or char_length(content) <= 2000),
  image_url  text,
  created_at timestamptz not null default now(),
  constraint messages_has_payload check (coalesce(trim(content), '') <> '' or image_url is not null)
);
create index if not exists messages_created_at_idx on public.messages (created_at desc);
alter table public.messages enable row level security;
drop policy if exists "messages_select_auth" on public.messages;
create policy "messages_select_auth" on public.messages for select to authenticated using (true);
drop policy if exists "messages_insert_own" on public.messages;
create policy "messages_insert_own" on public.messages for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "messages_delete_own" on public.messages;
create policy "messages_delete_own" on public.messages for delete to authenticated using (user_id = auth.uid() or public.is_owner());

-- 3) المهام (منتدى) + التثبيت للمالك فقط
create table if not exists public.tasks (
  id         bigint generated always as identity primary key,
  author_id  uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  title      text not null check (char_length(title) between 1 and 160),
  body       text check (body is null or char_length(body) <= 4000),
  status     text not null default 'open' check (status in ('open','in_progress','done')),
  pinned     boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.tasks enable row level security;
drop policy if exists "tasks_select_auth" on public.tasks;
create policy "tasks_select_auth" on public.tasks for select to authenticated using (true);
drop policy if exists "tasks_insert_own" on public.tasks;
create policy "tasks_insert_own" on public.tasks for insert to authenticated
  with check (author_id = auth.uid() and pinned = false);
drop policy if exists "tasks_update_author_or_owner" on public.tasks;
create policy "tasks_update_author_or_owner" on public.tasks for update to authenticated
  using (author_id = auth.uid() or public.is_owner()) with check (author_id = auth.uid() or public.is_owner());
drop policy if exists "tasks_delete_author_or_owner" on public.tasks;
create policy "tasks_delete_author_or_owner" on public.tasks for delete to authenticated
  using (author_id = auth.uid() or public.is_owner());

create or replace function public.guard_task_pin()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.pinned is distinct from old.pinned and not public.is_owner() then
    raise exception 'Only the owner can pin tasks';
  end if;
  new.author_id := old.author_id;
  return new;
end $$;
drop trigger if exists tasks_guard_pin on public.tasks;
create trigger tasks_guard_pin before update on public.tasks for each row execute function public.guard_task_pin();

create table if not exists public.task_replies (
  id         bigint generated always as identity primary key,
  task_id    bigint not null references public.tasks(id) on delete cascade,
  author_id  uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  body       text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);
create index if not exists task_replies_task_idx on public.task_replies (task_id, created_at);
alter table public.task_replies enable row level security;
drop policy if exists "replies_select_auth" on public.task_replies;
create policy "replies_select_auth" on public.task_replies for select to authenticated using (true);
drop policy if exists "replies_insert_own" on public.task_replies;
create policy "replies_insert_own" on public.task_replies for insert to authenticated with check (author_id = auth.uid());
drop policy if exists "replies_delete_own_or_owner" on public.task_replies;
create policy "replies_delete_own_or_owner" on public.task_replies for delete to authenticated
  using (author_id = auth.uid() or public.is_owner());

-- 4) الوقت الحقيقي
do $$ begin alter publication supabase_realtime add table public.messages;     exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.tasks;        exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.task_replies; exception when duplicate_object then null; end $$;

-- 5) التخزين: الصور الشخصية + صور المحادثة
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('avatars',     'avatars',     true, 5242880, array['image/jpeg','image/png','image/webp','image/gif']),
  ('chat-images', 'chat-images', true, 5242880, array['image/jpeg','image/png','image/webp','image/gif'])
on conflict (id) do update set public = true, file_size_limit = 5242880,
  allowed_mime_types = array['image/jpeg','image/png','image/webp','image/gif'];

do $$ declare b text; begin
  foreach b in array array['avatars','chat-images'] loop
    execute format('drop policy if exists "%s_read" on storage.objects', b);
    execute format('create policy "%s_read" on storage.objects for select using (bucket_id = %L)', b, b);
    execute format('drop policy if exists "%s_upload_own" on storage.objects', b);
    execute format('create policy "%s_upload_own" on storage.objects for insert to authenticated with check (bucket_id = %L and (storage.foldername(name))[1] = auth.uid()::text)', b, b);
    execute format('drop policy if exists "%s_delete_own" on storage.objects', b);
    execute format('create policy "%s_delete_own" on storage.objects for delete to authenticated using (bucket_id = %L and (storage.foldername(name))[1] = auth.uid()::text)', b, b);
  end loop;
end $$;
