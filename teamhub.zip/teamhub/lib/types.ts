export const SPECIALTIES = [
  { id: 'frontend', label: 'Frontend' },
  { id: 'backend', label: 'Backend' },
  { id: 'fullstack', label: 'Full-Stack' },
  { id: 'mobile', label: 'Mobile' },
  { id: 'ui_ux', label: 'UI / UX' },
  { id: 'devops', label: 'DevOps' },
  { id: 'ai', label: 'AI / Data' },
  { id: 'qa', label: 'QA / Security' }
] as const;

export type Specialty = (typeof SPECIALTIES)[number]['id'];
export const specialtyLabel = (id?: string | null) => SPECIALTIES.find((s) => s.id === id)?.label ?? 'Not set';

export interface Profile {
  id: string;
  display_name: string;
  specialty: Specialty | null;
  bio: string | null;
  avatar_url: string | null;
  is_owner: boolean;
  onboarded: boolean;
  created_at: string;
}
export interface Message { id: number; user_id: string; content: string | null; image_url: string | null; created_at: string }
export type TaskStatus = 'open' | 'in_progress' | 'done';
export interface Task { id: number; author_id: string; title: string; body: string | null; status: TaskStatus; pinned: boolean; created_at: string }
export interface Reply { id: number; task_id: number; author_id: string; body: string; created_at: string }
export interface Online { id: string; name: string; avatar: string | null; path: string }
