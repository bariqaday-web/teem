'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { usePresence } from '@/lib/presence';
import { Avatar, Badge, Card, Eyebrow } from '@/components/ui/ui';
import { SPECIALTIES, specialtyLabel, Profile } from '@/lib/types';
import { cn } from '@/lib/utils';

export default function PeoplePage() {
  const [people, setPeople] = useState<Profile[]>([]);
  const [filter, setFilter] = useState<string>('all');
  const online = usePresence();
  useEffect(() => { supabase.from('profiles').select('*').eq('onboarded', true).order('created_at').then(({ data }) => setPeople((data ?? []) as Profile[])); }, []);
  const shown = people.filter((p) => filter === 'all' || p.specialty === filter);

  return (
    <div>
      <Eyebrow>The team</Eyebrow>
      <h1 className="display mt-4 text-4xl font-bold tracking-tight sm:text-5xl">Sharp by nature.</h1>
      <div className="mt-8 flex flex-wrap gap-2">
        {[{ id: 'all', label: 'Everyone' }, ...SPECIALTIES].map((s) => (
          <button key={s.id} onClick={() => setFilter(s.id)} className={cn('rounded-xl border px-4 py-2.5 text-sm transition', filter === s.id ? 'border-coral/30 bg-coral/10 text-orange-100' : 'border-white/10 bg-white/5 text-slate-300 hover:border-white/25')}>{s.label}</button>
        ))}
      </div>
      <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {shown.map((p) => (
          <Card key={p.id} className="rise p-6">
            <div className="flex items-center gap-4">
              <span className="relative"><Avatar name={p.display_name} url={p.avatar_url} size={56} />{online.some((o) => o.id === p.id) && <i className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-emerald-400 ring-2 ring-[#121218]" />}</span>
              <div className="min-w-0"><h3 className="display truncate text-xl font-bold">{p.display_name}</h3><div className="mt-1 flex gap-2"><Badge>{specialtyLabel(p.specialty)}</Badge>{p.is_owner && <Badge className="bg-amberx/15 text-amber-100">Owner</Badge>}</div></div>
            </div>
            {p.bio && <p dir="auto" className="mt-4 text-sm leading-6 text-slate-400">{p.bio}</p>}
          </Card>
        ))}
        {shown.length === 0 && <p className="text-sm text-slate-500">No one here yet.</p>}
      </div>
    </div>
  );
}
