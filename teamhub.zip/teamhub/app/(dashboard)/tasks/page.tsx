'use client';
import { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import TaskCard from '@/components/TaskCard';
import { Button, Card, Eyebrow, Input, Textarea } from '@/components/ui/ui';
import type { Profile, Reply, Task } from '@/lib/types';

export default function TasksPage() {
  const { profile } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [replies, setReplies] = useState<Reply[]>([]);
  const [people, setPeople] = useState<Map<string, Profile>>(new Map());
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    const [t, r, p] = await Promise.all([
      supabase.from('tasks').select('*').order('pinned', { ascending: false }).order('created_at', { ascending: false }),
      supabase.from('task_replies').select('*').order('created_at', { ascending: true }),
      supabase.from('profiles').select('*')
    ]);
    setTasks((t.data ?? []) as Task[]); setReplies((r.data ?? []) as Reply[]);
    setPeople(new Map(((p.data ?? []) as Profile[]).map((x) => [x.id, x])));
    if (t.error) setErr(t.error.message);
  }, []);

  useEffect(() => {
    load();
    const ch = supabase.channel('tasks-forum')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tasks' }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'task_replies' }, load).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [load]);

  async function create(e: React.FormEvent) {
    e.preventDefault(); if (!title.trim()) return;
    const { error } = await supabase.from('tasks').insert({ title: title.trim(), body: body.trim() || null });
    if (error) { setErr(error.message); return; }
    setTitle(''); setBody(''); setErr(''); load();
  }

  return (
    <div>
      <Eyebrow>Task forum</Eyebrow>
      <h1 className="display mt-4 text-4xl font-bold tracking-tight sm:text-5xl">Ideas, made tangible.</h1>
      <Card className="mt-8 p-6">
        <form onSubmit={create}>
          <Input dir="auto" className="mt-0" placeholder="Task title" value={title} maxLength={160} onChange={(e) => setTitle(e.target.value)} />
          <Textarea dir="auto" rows={2} placeholder="Details (optional)" value={body} onChange={(e) => setBody(e.target.value)} />
          <div className="mt-3 flex items-center justify-between"><p className="text-xs text-red-300">{err}</p><Button type="submit">Post task</Button></div>
        </form>
      </Card>
      <p className="mt-4 text-xs text-slate-500">{profile?.is_owner ? 'You are the owner: you can pin, change status and delete any task.' : 'Only the owner can pin tasks.'}</p>
      <div className="mt-6 grid gap-5 md:grid-cols-2">
        {tasks.map((t) => <TaskCard key={t.id} task={t} replies={replies.filter((r) => r.task_id === t.id)} people={people} onChange={load} />)}
        {tasks.length === 0 && <p className="text-sm text-slate-500">No tasks yet. Post the first one.</p>}
      </div>
    </div>
  );
}
