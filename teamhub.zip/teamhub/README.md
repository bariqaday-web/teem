# TeamHub

موقع إدارة فريق متكامل: Next.js (App Router) + Tailwind + Supabase، بتصميم AuraFolio (Syne + Inter، coral #FF5E36 على #0A0A0C).

## الصفحات
- `/login` `/signup` تسجيل الدخول وإنشاء حساب — `/onboarding` إكمال الملف الشخصي (الاسم، التخصص، النبذة، الصورة)
- `/workspace` التواجد الحي + غرفة الصوت — `/chat` محادثة فورية + رفع صور + تنبيهات المتصفح
- `/tasks` منتدى المهام (التثبيت للمالك فقط) — `/people` أعضاء الفريق وتخصصاتهم

## التشغيل
1. شغّل `supabase/schema.sql` كاملاً في Supabase ‏> SQL Editor (أول حساب يسجّل يصبح المالك).
2. (اختياري للتجربة السريعة) Authentication > Providers > Email: عطّل "Confirm email".
3. `npm install` ثم `npm run dev` وافتح http://localhost:3000
4. للنشر (Netlify/Vercel) أضف المتغيرين في `.env.example` كمتغيرات بيئة.

## ملاحظة
غرفة الصوت تعرض من بداخل الغرفة وحالة الكتم ومؤشر التحدث لحظياً، لكن نقل الصوت بين الأعضاء يحتاج WebRTC أو Agora (غير مضاف).
